package br.com.favelasoundmenu;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class OverlayService extends Service {
    private WindowManager windowManager;
    private View panel;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;

    private final int bg = Color.rgb(20, 21, 25);
    private final int card = Color.rgb(35, 37, 43);
    private final int accent = Color.rgb(255, 176, 0);
    private final int white = Color.rgb(245, 246, 248);

    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Autorize a sobreposição nas configurações do Android.", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createPanel();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView label(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button action(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setAllCaps(false);
        b.setTextColor(Color.BLACK);
        b.setTextSize(13);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        return b;
    }

    private void createPanel() {
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dp(12), dp(12), dp(12), dp(12));
        outer.setBackground(rounded(bg, 18));
        outer.setElevation(dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("FAVELA SOUND", 18, accent);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));
        Button close = action("Fechar");
        close.setOnClickListener(v -> stopSelf());
        header.addView(close, new LinearLayout.LayoutParams(-2, dp(42)));
        header.setOnTouchListener((v, event) -> dragPanel(event));
        outer.addView(header);

        TextView sub = label("PAINEL DE MONTAGEM • DEMO", 10, Color.LTGRAY);
        outer.addView(sub);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(10), 0, 0);

        addSection(content, "🔊  ALTO-FALANTES",
            new String[]{"Subwoofer 12 pol.", "Woofer médio-grave", "Driver", "Super tweeter"});
        addSection(content, "⚡  MÓDULOS",
            new String[]{"Amplificador", "Módulo para grave"});
        addSection(content, "💡  ILUMINAÇÃO",
            new String[]{"LED âmbar", "Painel VU ilustrativo"});
        addSection(content, "🧰  ACESSÓRIOS",
            new String[]{"Caixa acústica", "Grade de proteção"});

        TextView footer = label("Itens ilustrativos; não alteram o jogo.", 11, Color.LTGRAY);
        footer.setPadding(dp(4), dp(12), dp(4), dp(4));
        content.addView(footer);

        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView move = label("Segure aqui para mover • Favela Sound Menu 0.1", 10, Color.GRAY);
        move.setPadding(dp(4), dp(8), dp(4), 0);
        outer.addView(move);
        move.setOnTouchListener((v, event) -> dragPanel(event));

        panel = outer;
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
            dp(310), dp(520), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.END;
        params.x = dp(12);
        params.y = dp(70);
        try {
            windowManager.addView(panel, params);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o painel: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void addSection(LinearLayout parent, String title, String[] items) {
        TextView heading = label(title, 13, accent);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setPadding(dp(4), dp(8), dp(4), dp(5));
        parent.addView(heading);
        for (String item : items) {
            Button b = action(item);
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(card));
            b.setTextColor(white);
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            b.setPadding(dp(12), 0, dp(8), 0);
            b.setOnClickListener(v ->
                Toast.makeText(this, item + ": item de demonstração", Toast.LENGTH_SHORT).show());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(42));
            lp.bottomMargin = dp(6);
            parent.addView(b, lp);
        }
    }

    private boolean dragPanel(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX();
                downY = event.getRawY();
                startX = params.x;
                startY = params.y;
                return true;
            case MotionEvent.ACTION_MOVE:
                params.x = startX + (int) (downX - event.getRawX());
                params.y = startY + (int) (event.getRawY() - downY);
                try {
                    windowManager.updateViewLayout(panel, params);
                } catch (Exception ignored) {}
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onDestroy() {
        if (windowManager != null && panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
